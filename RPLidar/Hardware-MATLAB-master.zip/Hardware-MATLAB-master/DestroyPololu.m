function DestroyPololu(pPololu)
calllib('hardwarex', 'DestroyPololux', pPololu);
