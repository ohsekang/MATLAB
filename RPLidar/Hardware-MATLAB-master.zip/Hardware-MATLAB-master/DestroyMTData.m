function DestroyMTData(pMTData)
calllib('hardwarex', 'DestroyMTDatax', pMTData);
