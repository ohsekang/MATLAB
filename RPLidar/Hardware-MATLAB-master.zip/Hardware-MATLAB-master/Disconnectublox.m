function [result] = Disconnectublox(publox)
result = calllib('hardwarex', 'Disconnectubloxx', publox);
