function DestroyHokuyo(pHokuyo)
calllib('hardwarex', 'DestroyHokuyox', pHokuyo);
