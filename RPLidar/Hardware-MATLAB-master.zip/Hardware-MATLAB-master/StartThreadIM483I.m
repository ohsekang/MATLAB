function [result] = StartThreadIM483I(pIM483I)
result = calllib('hardwarex', 'StartThreadIM483Ix', pIM483I);
