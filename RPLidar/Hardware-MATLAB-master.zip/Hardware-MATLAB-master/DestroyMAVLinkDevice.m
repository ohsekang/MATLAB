function DestroyMAVLinkDevice(pMAVLinkDevice)
calllib('hardwarex', 'DestroyMAVLinkDevicex', pMAVLinkDevice);
