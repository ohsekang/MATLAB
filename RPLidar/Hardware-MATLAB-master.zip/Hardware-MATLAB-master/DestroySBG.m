function DestroySBG(pSBG)
calllib('hardwarex', 'DestroySBGx', pSBG);
