function DestroyMAVLinkData(pMAVLinkData)
calllib('hardwarex', 'DestroyMAVLinkDatax', pMAVLinkData);
