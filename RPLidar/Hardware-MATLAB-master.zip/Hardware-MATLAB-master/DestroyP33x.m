function DestroyP33x(pP33x)
calllib('hardwarex', 'DestroyP33xx', pP33x);
