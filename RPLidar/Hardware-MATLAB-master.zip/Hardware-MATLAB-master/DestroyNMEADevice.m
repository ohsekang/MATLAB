function DestroyNMEADevice(pNMEADevice)
calllib('hardwarex', 'DestroyNMEADevicex', pNMEADevice);
