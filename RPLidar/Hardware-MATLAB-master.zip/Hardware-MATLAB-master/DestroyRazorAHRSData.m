function DestroyRazorAHRSData(pRazorAHRSData)
calllib('hardwarex', 'DestroyRazorAHRSDatax', pRazorAHRSData);
