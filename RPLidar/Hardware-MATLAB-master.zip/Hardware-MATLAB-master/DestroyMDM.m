function DestroyMDM(pMDM)
calllib('hardwarex', 'DestroyMDMx', pMDM);
