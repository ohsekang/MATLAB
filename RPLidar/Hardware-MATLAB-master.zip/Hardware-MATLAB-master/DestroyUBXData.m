function DestroyUBXData(pUBXData)
calllib('hardwarex', 'DestroyUBXDatax', pUBXData);
