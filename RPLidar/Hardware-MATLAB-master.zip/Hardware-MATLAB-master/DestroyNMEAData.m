function DestroyNMEAData(pNMEAData)
calllib('hardwarex', 'DestroyNMEADatax', pNMEAData);
