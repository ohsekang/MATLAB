function DestroyRPLIDAR(pRPLIDAR)
calllib('hardwarex', 'DestroyRPLIDARx', pRPLIDAR);
