function DestroyRazorAHRS(pRazorAHRS)
calllib('hardwarex', 'DestroyRazorAHRSx', pRazorAHRS);
