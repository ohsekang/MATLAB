function [result] = StopThreadIM483I(pIM483I)
result = calllib('hardwarex', 'StopThreadIM483Ix', pIM483I);
