function [result] = StopThreadP33x(pP33x)
result = calllib('hardwarex', 'StopThreadP33xx', pP33x);
