function DestroySBGData(pSBGData)
calllib('hardwarex', 'DestroySBGDatax', pSBGData);
