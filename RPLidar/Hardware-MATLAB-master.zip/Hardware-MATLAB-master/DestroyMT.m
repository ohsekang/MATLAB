function DestroyMT(pMT)
calllib('hardwarex', 'DestroyMTx', pMT);
