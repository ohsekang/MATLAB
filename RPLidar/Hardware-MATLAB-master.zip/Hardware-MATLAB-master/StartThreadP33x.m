function [result] = StartThreadP33x(pP33x)
result = calllib('hardwarex', 'StartThreadP33xx', pP33x);
