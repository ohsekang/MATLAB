function [result] = StartNMEAThreadublox(publox)
result = calllib('hardwarex', 'StartNMEAThreadubloxx', publox);
