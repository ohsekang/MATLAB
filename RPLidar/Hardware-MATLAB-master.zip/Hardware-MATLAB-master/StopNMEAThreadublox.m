function [result] = StopNMEAThreadublox(publox)
result = calllib('hardwarex', 'StopNMEAThreadubloxx', publox);
