function Destroyublox(publox)
calllib('hardwarex', 'Destroyubloxx', publox);
