function [result] = StartUBXThreadublox(publox)
result = calllib('hardwarex', 'StartUBXThreadubloxx', publox);
