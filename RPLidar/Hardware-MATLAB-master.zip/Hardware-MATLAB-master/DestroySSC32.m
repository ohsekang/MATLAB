function DestroySSC32(pSSC32)
calllib('hardwarex', 'DestroySSC32x', pSSC32);
