/* C thunk file for functions in hardwarex_proto.m generated on Tue May  3 16:00:07 2022. */


#ifdef _WIN32
  #define DLL_EXPORT_SYM __declspec(dllexport)
#elif __GNUC__ >= 4
  #define DLL_EXPORT_SYM __attribute__ ((visibility("default")))
#else
  #define DLL_EXPORT_SYM
#endif

#ifdef LCC_WIN64
  #define DLL_EXPORT_SYM
#endif

#ifdef  __cplusplus
#define EXPORT_EXTERN_C extern "C" DLL_EXPORT_SYM
#else
#define EXPORT_EXTERN_C DLL_EXPORT_SYM
#endif

#include <tmwtypes.h>

/* use BUILDING_THUNKFILE to protect parts of your header if needed when building the thunkfile */
#define BUILDING_THUNKFILE

#include "hardwarex.h"
#ifdef LCC_WIN64
#define EXPORT_EXTERN_C __declspec(dllexport)
#endif

/*  SBG * CreateSBGx ( void ); */
EXPORT_EXTERN_C void * voidPtrvoidThunk(void fcn(),const char *callstack,int stacksize)
{
	return ((void * (*)(void ))fcn)();
}

/*  void DestroySBGx ( SBG * pSBG ); */
EXPORT_EXTERN_C void voidvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	((void (*)(void * ))fcn)(p0);
}

/*  int GetLatestDataSBGx ( SBG * pSBG , SBGDATA * pSBGData ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	return ((int32_T (*)(void * , void * ))fcn)(p0 , p1);
}

/*  int ConnectSBGx ( SBG * pSBG , char * szCfgFilePath ); */
EXPORT_EXTERN_C int32_T int32voidPtrcstringThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	char * p1;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(char * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	return ((int32_T (*)(void * , char * ))fcn)(p0 , p1);
}

/*  int DisconnectSBGx ( SBG * pSBG ); */
EXPORT_EXTERN_C int32_T int32voidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	return ((int32_T (*)(void * ))fcn)(p0);
}

/*  int SendDataMDMx ( MDM * pMDM , unsigned char * buf , int buflen , int * pSentBytes ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrint32voidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	int32_T p2;
	void * p3;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(int32_T const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	p3=*(void * const *)callstack;
	callstack+=sizeof(p3) % sizeof(size_t) ? ((sizeof(p3) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p3);
	return ((int32_T (*)(void * , void * , int32_T , void * ))fcn)(p0 , p1 , p2 , p3);
}

/*  int SetMotorTorqueIM483Ix ( IM483I * pIM483I , int holdpercent , int runpercent ); */
EXPORT_EXTERN_C int32_T int32voidPtrint32int32Thunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	int32_T p1;
	int32_T p2;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(int32_T const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(int32_T const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	return ((int32_T (*)(void * , int32_T , int32_T ))fcn)(p0 , p1 , p2);
}

/*  int SetMotorSpeedIM483Ix ( IM483I * pIM483I , int val ); */
EXPORT_EXTERN_C int32_T int32voidPtrint32Thunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	int32_T p1;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(int32_T const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	return ((int32_T (*)(void * , int32_T ))fcn)(p0 , p1);
}

/*  int SetMaxAngleIM483Ix ( IM483I * pIM483I , double angle ); */
EXPORT_EXTERN_C int32_T int32voidPtrdoubleThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	double p1;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(double const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	return ((int32_T (*)(void * , double ))fcn)(p0 , p1);
}

/*  int GetVoltageSSC32x ( SSC32 * pSSC32 , int channel , double * pVoltage ); */
EXPORT_EXTERN_C int32_T int32voidPtrint32voidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	int32_T p1;
	void * p2;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(int32_T const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	return ((int32_T (*)(void * , int32_T , void * ))fcn)(p0 , p1 , p2);
}

/*  int SetAllPWMsSSC32x ( SSC32 * pSSC32 , int * selectedchannels , int * pws ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	void * p2;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	return ((int32_T (*)(void * , void * , void * ))fcn)(p0 , p1 , p2);
}

/*  double k2angleHokuyox ( HOKUYO * pHokuyo , int k ); */
EXPORT_EXTERN_C double doublevoidPtrint32Thunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	int32_T p1;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(int32_T const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	return ((double (*)(void * , int32_T ))fcn)(p0 , p1);
}

/*  int GetInfoRequestRPLIDARx ( RPLIDAR * pRPLIDAR , int * pModelID , int * pHardwareVersion , int * pFirmwareMajor , int * pFirmwareMinor , char * SerialNumber ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrvoidPtrvoidPtrvoidPtrcstringThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	void * p2;
	void * p3;
	void * p4;
	char * p5;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	p3=*(void * const *)callstack;
	callstack+=sizeof(p3) % sizeof(size_t) ? ((sizeof(p3) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p3);
	p4=*(void * const *)callstack;
	callstack+=sizeof(p4) % sizeof(size_t) ? ((sizeof(p4) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p4);
	p5=*(char * const *)callstack;
	callstack+=sizeof(p5) % sizeof(size_t) ? ((sizeof(p5) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p5);
	return ((int32_T (*)(void * , void * , void * , void * , void * , char * ))fcn)(p0 , p1 , p2 , p3 , p4 , p5);
}

/*  int GetAllSupportedScanModesRPLIDARx ( RPLIDAR * pRPLIDAR , int * pScanModeIDs , double * pusPerSamples , double * pMaxDistances , int * pAnsTypes , char ** pScanModeNames ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrvoidPtrvoidPtrvoidPtrvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	void * p2;
	void * p3;
	void * p4;
	void * p5;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	p3=*(void * const *)callstack;
	callstack+=sizeof(p3) % sizeof(size_t) ? ((sizeof(p3) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p3);
	p4=*(void * const *)callstack;
	callstack+=sizeof(p4) % sizeof(size_t) ? ((sizeof(p4) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p4);
	p5=*(void * const *)callstack;
	callstack+=sizeof(p5) % sizeof(size_t) ? ((sizeof(p5) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p5);
	return ((int32_T (*)(void * , void * , void * , void * , void * , void * ))fcn)(p0 , p1 , p2 , p3 , p4 , p5);
}

/*  int GetScanDataResponseRPLIDARx ( RPLIDAR * pRPLIDAR , double * pDistance , double * pAngle , BOOL * pbNewScan , int * pQuality ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrvoidPtrvoidPtrvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	void * p2;
	void * p3;
	void * p4;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	p3=*(void * const *)callstack;
	callstack+=sizeof(p3) % sizeof(size_t) ? ((sizeof(p3) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p3);
	p4=*(void * const *)callstack;
	callstack+=sizeof(p4) % sizeof(size_t) ? ((sizeof(p4) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p4);
	return ((int32_T (*)(void * , void * , void * , void * , void * ))fcn)(p0 , p1 , p2 , p3 , p4);
}

/*  int GetExpressScanDataResponseRPLIDARx ( RPLIDAR * pRPLIDAR , double * pDistances , double * pAngles , BOOL * pbNewScan ); */
EXPORT_EXTERN_C int32_T int32voidPtrvoidPtrvoidPtrvoidPtrThunk(void fcn(),const char *callstack,int stacksize)
{
	void * p0;
	void * p1;
	void * p2;
	void * p3;
	p0=*(void * const *)callstack;
	callstack+=sizeof(p0) % sizeof(size_t) ? ((sizeof(p0) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p0);
	p1=*(void * const *)callstack;
	callstack+=sizeof(p1) % sizeof(size_t) ? ((sizeof(p1) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p1);
	p2=*(void * const *)callstack;
	callstack+=sizeof(p2) % sizeof(size_t) ? ((sizeof(p2) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p2);
	p3=*(void * const *)callstack;
	callstack+=sizeof(p3) % sizeof(size_t) ? ((sizeof(p3) / sizeof(size_t)) + 1) * sizeof(size_t):sizeof(p3);
	return ((int32_T (*)(void * , void * , void * , void * ))fcn)(p0 , p1 , p2 , p3);
}

