function [result] = StopUBXThreadublox(publox)
result = calllib('hardwarex', 'StopUBXThreadubloxx', publox);
